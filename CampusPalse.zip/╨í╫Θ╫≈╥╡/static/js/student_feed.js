async function fetchFeed() {
  const feed = document.getElementById("feed");
  try {
    const res = await fetch(`/api/comments/${courseId}`);
    const data = await res.json();

    if (!data.comments || data.comments.length === 0) {
      feed.innerHTML = `<div class="muted">No comments yet. Be the first to ask!</div>`;
      return;
    }

    feed.innerHTML = data.comments.map(c => {
      const statusBadge = c.status === "resolved"
        ? `<span class="badge badge-resolved">resolved</span>`
        : `<span class="badge badge-open">open</span>`;

      const note = c.lecturer_note
        ? `<div class="muted small">Lecturer note: ${escapeHtml(c.lecturer_note)}</div>`
        : "";

      return `
        <div class="item">
          <div class="meta">
            <div>
              <strong>${escapeHtml(c.name)}</strong>
              <span class="muted small"> · ${escapeHtml(c.created_at)}</span>
            </div>
            <div>${statusBadge}</div>
          </div>
          <div class="content">${escapeHtml(c.content)}</div>
          ${note}
        </div>
      `;
    }).join("");
  } catch (e) {
    feed.innerHTML = `<div class="muted">Failed to load feed. Refresh the page.</div>`;
  }
}

function escapeHtml(str) {
  return String(str)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

fetchFeed();
setInterval(fetchFeed, 3000);
